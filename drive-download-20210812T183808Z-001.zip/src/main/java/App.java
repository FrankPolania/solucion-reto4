import view.VistaRequerimientos;

public class App {
    public static void main( String[] args ){        

        //Casos de prueba 

        //Requerimiento 1 - Reto3
        VistaRequerimientos.requerimiento1();
        System.out.println();

         //Requerimiento 2 - Reto3
         VistaRequerimientos.requerimiento2();
         System.out.println();

        //Requerimiento 5 - Reto3
        VistaRequerimientos.requerimiento3();
        System.out.println();
    }

}
