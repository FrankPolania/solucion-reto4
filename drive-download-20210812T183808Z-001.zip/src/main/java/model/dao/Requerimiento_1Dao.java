package model.dao;

//Estructura de datos
import java.util.ArrayList;

//Librerías para SQL y Base de Datos
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//Clase para conexión
import util.JDBCUtilities;

//Encapsulamiento de los datos
import model.vo.Requerimiento_1;

public class Requerimiento_1Dao {
    
    public ArrayList<Requerimiento_1> requerimiento1() throws SQLException {
        // Su código
    }
    
}
