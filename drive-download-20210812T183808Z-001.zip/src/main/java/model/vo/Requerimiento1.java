package model.vo;

public class Requerimiento1 {
    //Su codigo
    
}
