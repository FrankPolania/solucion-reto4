package model.vo;

public class Requerimiento2 {
    //Su codigo
    
    
}
